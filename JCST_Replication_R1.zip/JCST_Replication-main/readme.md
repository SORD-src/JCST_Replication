1. data.csv contains features and prediction classes applied to train our machine learners. Each row represents features of one developer.
2. The .conf files are configurations to perform Codeface4Smells detections.  The manual and source code of the tool is available in:  https://github.com/maelstromdat/CodeFace4Smells
3. The sentiment dataset is available in: http://ansymore.uantwerpen.be/system/files/uploads/artefacts/alessandro/MSR16/archive3.zip

